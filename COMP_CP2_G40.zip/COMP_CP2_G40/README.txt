A execu��o dever� ser feita atrav�s de IntelliJ, com recurso ao plugin de antlr.

O ficheiro de teste dever� ser alterado no Main.java ou dever� ter sempre o nome "teste.bgl.xml"